package myhome;

import java.util.ArrayList;

public class CartList {
	private ArrayList<Integer> codeList=new ArrayList<Integer>();
	private ArrayList<String> nameList=new ArrayList<String>();
	private ArrayList<Integer> priceList=new ArrayList<Integer>();
	private ArrayList<Integer> numList = new ArrayList<Integer>();
	public int getItemSize(){
		return codeList.size();
	}
	public Integer[] getNumList(){
		return numList.toArray(new Integer[numList.size()]);
	}
	public Integer[] getPriceList(){
		return priceList.toArray(new Integer[priceList.size()]);
	}
	public String[] getNameList(){
		return nameList.toArray(new String[nameList.size()]);
	}
	public Integer[] getCodeList(){
		return codeList.toArray(new Integer[codeList.size()]);
	}
	public void setCodeList(int index, Integer code){
		codeList.add(index, code);
	}
	public void setNameList(int index, String name){
		nameList.add(index, name);
	}
	public void setPriceList(int index, Integer price){
		priceList.add(index, price);
	}
	public void setNumList(int index, int num){
		numList.add(index, num);
	}
}






