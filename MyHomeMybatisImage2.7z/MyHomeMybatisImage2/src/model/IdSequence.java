package model;

public class IdSequence {
	private int last_id;
	private String name;
	public int getLast_id() {
		return last_id;
	}
	public void setLast_id(int last_id) {
		this.last_id = last_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
